(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["user-user-module"],{

/***/ "./src/app/user/trang-chu/footer/footer.component.html":
/*!*************************************************************!*\
  !*** ./src/app/user/trang-chu/footer/footer.component.html ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- Footer -->\n<footer class=\"page-footer font-small color\">\n  <br>\n  <!-- Footer Links -->\n  <div class=\"container text-center text-md-left mt-5\">\n\n    <!-- Grid row -->\n    <div class=\"row mt-3\">\n\n      <!-- Grid column -->\n      <div class=\"col-md-3 col-lg-4 col-xl-3 mx-auto mb-4\">\n\n        <!-- Content -->\n        <h5 class=\"text-uppercase font-weight-bold\">Thông tin</h5>\n        <hr class=\"deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto\" style=\"width: 260px;\">\n        <p class=\"font-weight-normal\">Là Thẩm Mỹ Viện có đội ngũ bác sĩ đến từ nước ngoài sẽ làm bạn hài lòng hãy đến\n          với chúng tôi để có nhan sắc rạng rở chúng tôi yêu bạn\n        </p>\n\n      </div>\n      <!-- Grid column -->\n\n      <!-- Grid column -->\n      <div class=\"col-md-2 col-lg-2 col-xl-2 mx-auto mb-4\">\n\n        <!-- Links -->\n        <h5 class=\"text-uppercase font-weight-bold\">hướng dẫn</h5>\n        <hr class=\"deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto\" style=\"width: 60px;\">\n        <p>\n          <a routerLink=\"/user/trang-khac/gioi-thieu\">Giới Thiệu</a>\n        </p>\n        <p>\n          <a routerLink=\"/user/trang-khac/san-pham\">Dịch Vụ</a>\n        </p>\n        <p>\n          <a routerLink=\"/user/trang-khac/tin-tuc\">Tin Tức</a>\n        </p>\n        <p>\n          <a routerLink=\"/user/trang-khac/tin-tuc\">Phẩu Thuật Thẩm mỹ</a>\n        </p>\n\n      </div>\n      <!-- Grid column -->\n\n      <!-- Grid column -->\n      <div class=\"col-md-3 col-lg-2 col-xl-2 mx-auto mb-4\">\n\n        <!-- Links -->\n        <h5 class=\"text-uppercase font-weight-bold\">hổ trợ </h5>\n        <hr class=\"deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto\" style=\"width: 60px;\">\n        <p>\n          <a routerLink=\"/user/trang-khac/lien-he\">Liên Hệ</a>\n        </p>\n        <p>\n          <a routerLink=\"/user/trang-khac/lien-he\">Gọi Cho Chúng Tôi</a>\n        </p>\n        <p>\n          <a routerLink=\"/user/trang-khac/san-pham\">Cửa Hàng</a>\n        </p>\n        <p>\n          <a routerLink=\"/user/trang-khac/lien-he\">Google Map</a>\n        </p>\n\n      </div>\n      <!-- Grid column -->\n\n      <!-- Grid column -->\n      <div class=\"col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4\">\n\n        <!-- Links -->\n        <h5 class=\"text-uppercase font-weight-bold\">liên hệ</h5>\n        <hr class=\"deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto\" style=\"width: 60px;\">\n        <p>\n          <i class=\"fa fa-home\"></i> Ngũ Hành Sơn , Đà Nẵng\n        </p>\n        <p>\n          <i class=\"fa fa-envelope\"></i> thammyvien.com\n        </p>\n        <p>\n          <i class=\"fa fa-phone\"></i> + 032 881 1678\n        </p>\n        <p>\n          <i class=\"fa fa-print\"></i> + 0162 881 1678\n        </p>\n\n      </div>\n      <!-- Grid column -->\n\n    </div>\n    <!-- Grid row -->\n\n  </div>\n  <!-- Footer Links -->\n\n  <!-- Copyright -->\n  <div class=\"footer-copyright text-center py-3\">© 2018 Copyright:\n    <a href=\"#\">THẨM MỸ VIỆN.com</a>\n  </div>\n  <!-- Copyright -->\n\n</footer>\n<!-- Footer -->"

/***/ }),

/***/ "./src/app/user/trang-chu/footer/footer.component.scss":
/*!*************************************************************!*\
  !*** ./src/app/user/trang-chu/footer/footer.component.scss ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".color {\n  background-color: #A65606; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlci90cmFuZy1jaHUvZm9vdGVyL0M6XFx4YW1wcFxcaHRkb2NzXFx0aGFtX215X3ZpZW4vc3JjXFxhcHBcXHVzZXJcXHRyYW5nLWNodVxcZm9vdGVyXFxmb290ZXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSwwQkFBeUIsRUFDNUIiLCJmaWxlIjoic3JjL2FwcC91c2VyL3RyYW5nLWNodS9mb290ZXIvZm9vdGVyLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbG9ye1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0E2NTYwNjtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/user/trang-chu/footer/footer.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/user/trang-chu/footer/footer.component.ts ***!
  \***********************************************************/
/*! exports provided: FooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterComponent", function() { return FooterComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var FooterComponent = /** @class */ (function () {
    function FooterComponent() {
    }
    FooterComponent.prototype.ngOnInit = function () {
    };
    FooterComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-footer',
            template: __webpack_require__(/*! ./footer.component.html */ "./src/app/user/trang-chu/footer/footer.component.html"),
            styles: [__webpack_require__(/*! ./footer.component.scss */ "./src/app/user/trang-chu/footer/footer.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], FooterComponent);
    return FooterComponent;
}());



/***/ }),

/***/ "./src/app/user/trang-chu/menu/menu.component.html":
/*!*********************************************************!*\
  !*** ./src/app/user/trang-chu/menu/menu.component.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- fixed-top -->\n<nav class=\"navbar fixed-top navbar-expand-lg navbar-dark c scrolling-navbar\">\n  <div class=\"container\">\n    <a routerLink=\"/user/trang-chu\">\n      <img src=\"../../../../assets/img/vinass.png\" width=\"150px\" height=\"100px\" alt=\"salem piano\">\n    </a>\n    <!-- <a title=\"piano\" class=\"indigo-text\" style=\"font-weight: 600\" routerLink=\"/user/trang-chu\">SALEM PIANO </a> -->\n    <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarSupportedContent\"\n      aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\" (click)=\"onClick($event)\">\n      <i class=\"fa fa-bars fa-2x black-text\"></i>\n    </button>\n    <div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">\n      <ul class=\"navbar-nav ml-auto mr-auto\">\n        <li class=\"nav-item  waves-light custum\" mdbWavesEffect>\n          <a class=\"nav-link\" style=\"color: #795548;font-size:14px;font-weight: 400\" routerLink=\"/user/trang-chu\">\n            TRANG CHỦ\n          </a>\n        </li>\n        <li class=\"nav-item waves-light\" mdbWavesEffect>\n          <div class=\"btn-group select \">\n\n            <!-- Basic dropdown -->\n            <a routerLink=\"/user/trang-khac/dieu-tri-da-spa\" class=\"mr-4\" type=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\" style=\"color: #795548;font-size:14px;font-weight: 400\">\n              ĐIỀU TRỊ DA & SPA\n            </a>\n\n            <div class=\"dropdown-menu\">\n              <a class=\"dropdown-item text-white\" style=\"font-weight: 500\" routerLink=\"/user/trang-khac/gioi-thieu\">Triệt\n                Lông</a>\n\n              <a class=\"dropdown-item text-white\" style=\"font-weight: 500\" routerLink=\"/user/trang-khac/hoc-piano\">Điều\n                Trị Da</a>\n\n              <a class=\"dropdown-item text-white\" style=\"font-weight: 500\" routerLink=\"/user/trang-khac/gioi-thieu\">Trẻ\n                Hóa Da</a>\n\n              <a class=\"dropdown-item text-white\" style=\"font-weight: 500\" routerLink=\"/user/trang-khac/gioi-thieu\">Chăm\n                Sóc Da</a>\n              <a class=\"dropdown-item text-white\" style=\"font-weight: 500\" routerLink=\"/user/trang-khac/gioi-thieu\">Chăm\n                Sóc Cơ Thể</a>\n            </div>\n            <!-- Basic dropdown -->\n\n\n          </div>\n        </li>\n\n        <li class=\"nav-item waves-light\" mdbWavesEffect>\n          <div class=\"btn-group select \">\n\n            <!-- Basic dropdown -->\n            <a routerLink=\"/user/trang-khac/phau-thuat-tham-my\" class=\"mr-4\" type=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\" style=\"color: #795548;font-size:14px;font-weight: 400\">\n              PHẨU THUẬT THẨM MỸ\n            </a>\n\n            <div class=\"dropdown-menu\">\n              <a class=\"dropdown-item text-white\" style=\"font-weight: 500\" routerLink=\"/user/trang-khac/gioi-thieu\">Phẩu\n                Thuật Căn Da</a>\n\n              <a class=\"dropdown-item text-white\" style=\"font-weight: 500\" routerLink=\"/user/trang-khac/hoc-piano\">Phẩu\n                Thuật Hút Mỡ</a>\n\n              <a class=\"dropdown-item text-white\" style=\"font-weight: 500\" routerLink=\"/user/trang-khac/gioi-thieu\">Phẩu\n                Thuật Môi</a>\n\n              <a class=\"dropdown-item text-white\" style=\"font-weight: 500\" routerLink=\"/user/trang-khac/gioi-thieu\">Hàm\n                Mặt</a>\n              <a class=\"dropdown-item text-white\" style=\"font-weight: 500\" routerLink=\"/user/trang-khac/gioi-thieu\">Thẩm\n                Mỹ Mắt</a>\n            </div>\n            <!-- Basic dropdown -->\n\n\n          </div>\n        </li>\n        <li class=\"nav-item waves-light\" mdbWavesEffect>\n          <div class=\"btn-group select \">\n\n            <!-- Basic dropdown -->\n            <a routerLink=\"/user/trang-khac/tham-my-khac\" class=\"mr-4\" type=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\" style=\"color: #795548;font-size:14px;font-weight: 400\">\n              THẨM MỸ KHÁC\n            </a>\n\n            <div class=\"dropdown-menu\">\n              <a class=\"dropdown-item text-white\" style=\"font-weight: 500\" routerLink=\"/user/trang-khac/gioi-thieu\">Trị\n                Hói Đầu</a>\n\n              <a class=\"dropdown-item text-white\" style=\"font-weight: 500\" routerLink=\"/user/trang-khac/hoc-piano\">Điều\n                Trị Hôi Nách</a>\n\n              <a class=\"dropdown-item text-white\" style=\"font-weight: 500\" routerLink=\"/user/trang-khac/gioi-thieu\">Phun\n                Xăm Điêu Khắc</a>\n\n            </div>\n            <!-- Basic dropdown -->\n\n\n          </div>\n        </li>\n        <li class=\"nav-item waves-light custum\" mdbWavesEffect>\n          <a class=\"nav-link\" style=\"color: #795548;font-size:14px;font-weight: 400\" href=\"#\">\n            DẬY NGHỀ\n          </a>\n        </li>\n        <li class=\"nav-item waves-light custum\" mdbWavesEffect>\n          <a class=\"nav-link\" style=\"color: #795548;font-size:14px;font-weight: 400\" routerLink=\"/user/trang-khac/my-pham\">\n            MỸ PHẨM\n          </a>\n        </li>\n        <li class=\"nav-item waves-light custum\" mdbWavesEffect>\n          <a class=\"nav-link\" style=\"color: #795548;font-size:14px;font-weight: 400\" routerLink=\"/user/trang-khac/lien-he\">\n            LIÊN HỆ\n          </a>\n        </li>\n      </ul>\n    </div>\n  </div>\n</nav>"

/***/ }),

/***/ "./src/app/user/trang-chu/menu/menu.component.scss":
/*!*********************************************************!*\
  !*** ./src/app/user/trang-chu/menu/menu.component.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".view {\n  background: url(\"https://mdbootstrap.com/img/Photos/Others/img (42).jpg\") no-repeat center center;\n  background-size: cover; }\n\n@media (min-width: 768px) {\n  .view {\n    overflow: visible;\n    margin-top: -56px; } }\n\n.navbar {\n  z-index: 1; }\n\n.navbar {\n  background-color: transparent; }\n\n.top-nav-collapse {\n  background-color: #ffca28; }\n\n@media only screen and (max-width: 768px) {\n  .navbar {\n    background-color: #ffca28; } }\n\n.c {\n  background-color: white;\n  z-index: 100; }\n\n.text {\n  color: red;\n  font-size: 90%;\n  font-weight: 400; }\n\n.dropdown-item:hover {\n  background-color: #212121; }\n\n.select {\n  padding-top: 8px;\n  padding-left: 7px; }\n\n.dropdown-menu {\n  background-color: #A65606; }\n\n.text-dropdown {\n  color: #FAFAFA; }\n\n@media (max-width: 1068px) {\n  .select {\n    padding-bottom: 10px; } }\n\n@media (min-width: 1068px) {\n  .custum {\n    padding-right: 14px; } }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlci90cmFuZy1jaHUvbWVudS9DOlxceGFtcHBcXGh0ZG9jc1xcdGhhbV9teV92aWVuL3NyY1xcYXBwXFx1c2VyXFx0cmFuZy1jaHVcXG1lbnVcXG1lbnUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxrR0FBZ0c7RUFDaEcsdUJBQXNCLEVBQ3pCOztBQUNEO0VBQ0k7SUFDSSxrQkFBaUI7SUFDakIsa0JBQWlCLEVBQ3BCLEVBQUE7O0FBRUw7RUFDSSxXQUFVLEVBQ2I7O0FBQ0Q7RUFDSSw4QkFBNkIsRUFDaEM7O0FBQ0Q7RUFDSSwwQkFBeUIsRUFDNUI7O0FBQ0Q7RUFDSTtJQUNJLDBCQUEwQixFQUM3QixFQUFBOztBQUlMO0VBQ0ksd0JBQXVCO0VBRXZCLGFBQVksRUFDZjs7QUFRRDtFQUVJLFdBQVc7RUFDWCxlQUFjO0VBQ2QsaUJBQWdCLEVBQ25COztBQUVEO0VBQ0ksMEJBQTBCLEVBQzdCOztBQUVEO0VBQ0ksaUJBQWdCO0VBQ2hCLGtCQUFpQixFQUNwQjs7QUFFRDtFQUNJLDBCQUF5QixFQUM1Qjs7QUFFRDtFQUNJLGVBQWMsRUFDakI7O0FBSUQ7RUFDSTtJQUNJLHFCQUFvQixFQUN2QixFQUFBOztBQUlMO0VBQ0k7SUFDSSxvQkFBbUIsRUFDdEIsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3VzZXIvdHJhbmctY2h1L21lbnUvbWVudS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi52aWV3IHtcclxuICAgIGJhY2tncm91bmQ6IHVybChcImh0dHBzOi8vbWRib290c3RyYXAuY29tL2ltZy9QaG90b3MvT3RoZXJzL2ltZyAoNDIpLmpwZ1wiKW5vLXJlcGVhdCBjZW50ZXIgY2VudGVyO1xyXG4gICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxufVxyXG5AbWVkaWEgKG1pbi13aWR0aDogNzY4cHgpIHtcclxuICAgIC52aWV3IHtcclxuICAgICAgICBvdmVyZmxvdzogdmlzaWJsZTtcclxuICAgICAgICBtYXJnaW4tdG9wOiAtNTZweDtcclxuICAgIH1cclxufVxyXG4ubmF2YmFyIHtcclxuICAgIHotaW5kZXg6IDE7XHJcbn1cclxuLm5hdmJhciB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxufVxyXG4udG9wLW5hdi1jb2xsYXBzZSB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZjYTI4O1xyXG59XHJcbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgIC5uYXZiYXIge1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmNhMjggO1xyXG4gICAgfVxyXG59XHJcblxyXG5cclxuLmN7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOndoaXRlIDtcclxuICAgIC8vIGhlaWdodDogNjBweDtcclxuICAgIHotaW5kZXg6IDEwMDtcclxufVxyXG4vLyAubmF2LWl0ZW17XHJcbi8vICAgICAvLyBwYWRkaW5nLXRvcDogMTVweDtcclxuLy8gfVxyXG5cclxuLy8gLm1lbnV7XHJcbi8vICAgICBwYWRkaW5nLWxlZnQ6IDE1cHg7XHJcbi8vIH1cclxuLnRleHR7XHJcbiAgICAvLyBjb2xvcjogIzc5NTU0OCA7XHJcbiAgICBjb2xvcjogcmVkIDtcclxuICAgIGZvbnQtc2l6ZTogOTAlO1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcclxufVxyXG5cclxuLmRyb3Bkb3duLWl0ZW06aG92ZXJ7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMjEyMTIxIDtcclxufVxyXG5cclxuLnNlbGVjdHtcclxuICAgIHBhZGRpbmctdG9wOiA4cHg7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDdweDtcclxufVxyXG5cclxuLmRyb3Bkb3duLW1lbnV7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yIDojQTY1NjA2O1xyXG59XHJcblxyXG4udGV4dC1kcm9wZG93bntcclxuICAgIGNvbG9yOiAjRkFGQUZBO1xyXG59XHJcblxyXG5cclxuXHJcbkBtZWRpYSAobWF4LXdpZHRoOiAxMDY4cHgpIHtcclxuICAgIC5zZWxlY3R7XHJcbiAgICAgICAgcGFkZGluZy1ib3R0b206IDEwcHg7XHJcbiAgICB9XHJcbn1cclxuXHJcblxyXG5AbWVkaWEgKG1pbi13aWR0aDogMTA2OHB4KSB7XHJcbiAgICAuY3VzdHVte1xyXG4gICAgICAgIHBhZGRpbmctcmlnaHQ6IDE0cHg7XHJcbiAgICB9XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/user/trang-chu/menu/menu.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/user/trang-chu/menu/menu.component.ts ***!
  \*******************************************************/
/*! exports provided: MenuComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenuComponent", function() { return MenuComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var MenuComponent = /** @class */ (function () {
    function MenuComponent() {
    }
    MenuComponent.prototype.ngOnInit = function () {
    };
    MenuComponent.prototype.onClick = function (e) {
        console.log('phong', e);
    };
    MenuComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-menu',
            template: __webpack_require__(/*! ./menu.component.html */ "./src/app/user/trang-chu/menu/menu.component.html"),
            styles: [__webpack_require__(/*! ./menu.component.scss */ "./src/app/user/trang-chu/menu/menu.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], MenuComponent);
    return MenuComponent;
}());



/***/ }),

/***/ "./src/app/user/user.component.html":
/*!******************************************!*\
  !*** ./src/app/user/user.component.html ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-menu></app-menu>\r\n\r\n<div>\r\n    <div class=\"pyro\">\r\n        <div class=\"before\"></div>\r\n        <div class=\"after\"></div>\r\n    </div>\r\n    <router-outlet>\r\n\r\n    </router-outlet>\r\n\r\n</div>\r\n<div class=\"fixed-action-btn animated  infinite bounce\" style=\"bottom: 10px; left: 2px;\">\r\n\r\n\r\n    <a href=\"tel:0394690998\" class=\"btn-floating btn-large color waves-light\" mdbWavesEffect (click)=\"fixed.toggle($event)\">\r\n        <i class=\"fa fa-phone\"></i>\r\n    </a>\r\n    <div class=\"chip red-text\">\r\n        GỌI NGAY\r\n    </div>\r\n</div>\r\n<app-footer></app-footer>"

/***/ }),

/***/ "./src/app/user/user.component.scss":
/*!******************************************!*\
  !*** ./src/app/user/user.component.scss ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".color {\n  background-color: #32CD32; }\n\nbody {\n  margin: 0;\n  padding: 0;\n  background: #000;\n  overflow: hidden; }\n\n.pyro > .before, .pyro > .after {\n  position: absolute;\n  width: 5px;\n  height: 5px;\n  border-radius: 50%;\n  box-shadow: 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff, 0 0 #fff;\n  -webkit-animation: 1s bang ease-out infinite backwards, 1s gravity ease-in infinite backwards, 5s position linear infinite backwards;\n  animation: 1s bang ease-out infinite backwards, 1s gravity ease-in infinite backwards, 5s position linear infinite backwards; }\n\n.pyro > .after {\n  -webkit-animation-delay: 1.25s, 1.25s, 1.25s;\n  animation-delay: 1.25s, 1.25s, 1.25s;\n  -webkit-animation-duration: 1.25s, 1.25s, 6.25s;\n  animation-duration: 1.25s, 1.25s, 6.25s; }\n\n@-webkit-keyframes bang {\n  to {\n    box-shadow: -240px -182.66666667px #002fff, 220px -41.66666667px #6fff00, 92px 74.33333333px #ff0066, -84px 45.33333333px #ff002f, 79px 11.33333333px #ff0040, 14px -150.66666667px #0026ff, -41px 36.33333333px #ff2200, 235px -289.66666667px #4800ff, 117px -391.66666667px #8cff00, -214px -171.66666667px #3c00ff, -220px -11.66666667px #51ff00, -77px 78.33333333px #ff2b00, 7px -403.66666667px #4800ff, 245px -125.66666667px #ff0009, -124px 55.33333333px #22ff00, -195px 16.33333333px #ff8400, -214px -181.66666667px #ff4000, 228px -151.66666667px #ffa200, -47px -179.66666667px #00ff33, 147px -172.66666667px #9100ff, 223px 15.33333333px #ff0015, -61px -392.66666667px #004dff, -134px -389.66666667px #ffae00, 164px -212.66666667px #00ff2f, 10px -152.66666667px #00ff48, 218px -313.66666667px #ff00d9, -4px 34.33333333px #001eff, -201px -157.66666667px #15ff00, -91px -58.66666667px #3cff00, -112px 48.33333333px #ff00cc, 49px -131.66666667px #ffe100, 59px -223.66666667px #ff00bb, 168px -254.66666667px #ff0099, 43px -370.66666667px #09ff00, 65px -116.66666667px #88ff00, 128px -385.66666667px #ffea00, -19px -96.66666667px #00ffe1, 236px 17.33333333px #00ff2f, -202px -189.66666667px #3cff00, 196px 67.33333333px #ff5500, 171px -323.66666667px #1eff00, 143px -335.66666667px #ff00c4, 135px -372.66666667px #ff004d, 51px -36.66666667px #ff002f, -63px -188.66666667px #ff00dd, -183px -220.66666667px #ff8400, 100px -282.66666667px #ff00c8, -202px -397.66666667px #ff0009, 208px -251.66666667px #ff5500, -245px -348.66666667px #00fffb, 85px -270.66666667px #00ff4d; } }\n\n@keyframes bang {\n  to {\n    box-shadow: -240px -182.66666667px #002fff, 220px -41.66666667px #6fff00, 92px 74.33333333px #ff0066, -84px 45.33333333px #ff002f, 79px 11.33333333px #ff0040, 14px -150.66666667px #0026ff, -41px 36.33333333px #ff2200, 235px -289.66666667px #4800ff, 117px -391.66666667px #8cff00, -214px -171.66666667px #3c00ff, -220px -11.66666667px #51ff00, -77px 78.33333333px #ff2b00, 7px -403.66666667px #4800ff, 245px -125.66666667px #ff0009, -124px 55.33333333px #22ff00, -195px 16.33333333px #ff8400, -214px -181.66666667px #ff4000, 228px -151.66666667px #ffa200, -47px -179.66666667px #00ff33, 147px -172.66666667px #9100ff, 223px 15.33333333px #ff0015, -61px -392.66666667px #004dff, -134px -389.66666667px #ffae00, 164px -212.66666667px #00ff2f, 10px -152.66666667px #00ff48, 218px -313.66666667px #ff00d9, -4px 34.33333333px #001eff, -201px -157.66666667px #15ff00, -91px -58.66666667px #3cff00, -112px 48.33333333px #ff00cc, 49px -131.66666667px #ffe100, 59px -223.66666667px #ff00bb, 168px -254.66666667px #ff0099, 43px -370.66666667px #09ff00, 65px -116.66666667px #88ff00, 128px -385.66666667px #ffea00, -19px -96.66666667px #00ffe1, 236px 17.33333333px #00ff2f, -202px -189.66666667px #3cff00, 196px 67.33333333px #ff5500, 171px -323.66666667px #1eff00, 143px -335.66666667px #ff00c4, 135px -372.66666667px #ff004d, 51px -36.66666667px #ff002f, -63px -188.66666667px #ff00dd, -183px -220.66666667px #ff8400, 100px -282.66666667px #ff00c8, -202px -397.66666667px #ff0009, 208px -251.66666667px #ff5500, -245px -348.66666667px #00fffb, 85px -270.66666667px #00ff4d; } }\n\n@-webkit-keyframes gravity {\n  to {\n    transform: translateY(200px);\n    -moz-transform: translateY(200px);\n    -webkit-transform: translateY(200px);\n    -o-transform: translateY(200px);\n    -ms-transform: translateY(200px);\n    opacity: 0; } }\n\n@keyframes gravity {\n  to {\n    transform: translateY(200px);\n    -moz-transform: translateY(200px);\n    -webkit-transform: translateY(200px);\n    -o-transform: translateY(200px);\n    -ms-transform: translateY(200px);\n    opacity: 0; } }\n\n@-webkit-keyframes position {\n  0%, 19.9% {\n    margin-top: 10%;\n    margin-left: 40%; }\n  20%, 39.9% {\n    margin-top: 40%;\n    margin-left: 30%; }\n  40%, 59.9% {\n    margin-top: 20%;\n    margin-left: 70%; }\n  60%, 79.9% {\n    margin-top: 30%;\n    margin-left: 20%; }\n  80%, 99.9% {\n    margin-top: 30%;\n    margin-left: 80%; } }\n\n@keyframes position {\n  0%, 19.9% {\n    margin-top: 10%;\n    margin-left: 40%; }\n  20%, 39.9% {\n    margin-top: 40%;\n    margin-left: 30%; }\n  40%, 59.9% {\n    margin-top: 20%;\n    margin-left: 70%; }\n  60%, 79.9% {\n    margin-top: 30%;\n    margin-left: 20%; }\n  80%, 99.9% {\n    margin-top: 30%;\n    margin-left: 80%; } }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlci9DOlxceGFtcHBcXGh0ZG9jc1xcdGhhbV9teV92aWVuL3NyY1xcYXBwXFx1c2VyXFx1c2VyLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksMEJBQXlCLEVBQzVCOztBQThFRDtFQUNFLFVBQVE7RUFDUixXQUFTO0VBQ1QsaUJBQWdCO0VBQ2hCLGlCQUFnQixFQUNqQjs7QUFFRDtFQUNFLG1CQUFrQjtFQUNsQixXQUFVO0VBQ1YsWUFBVztFQUNYLG1CQUFrQjtFQUNsQix5Z0JBcEVvQztFQTBDbEMscUlBMkJtSTtFQXhCbkksNkhBd0JtSSxFQUN0STs7QUFFRDtFQTlDSSw2Q0ErQzJDO0VBNUMzQyxxQ0E0QzJDO0VBdkMzQyxnREF3QzhDO0VBckM5Qyx3Q0FxQzhDLEVBQ2pEOztBQXhFRztFQTJFRjtJQUNFLDJoREFoRm9DLEVBQUEsRUFBQTs7QUFvQnBDO0VBMkRGO0lBQ0UsMmhEQWhGb0MsRUFBQSxFQUFBOztBQUlwQztFQWlGRjtJQW5DRSw2QkFvQ29DO0lBbkNwQyxrQ0FtQ29DO0lBbENwQyxxQ0FrQ29DO0lBakNwQyxnQ0FpQ29DO0lBaENwQyxpQ0FnQ29DO0lBQ3BDLFdBQVUsRUFBQSxFQUFBOztBQW5FVjtFQWlFRjtJQW5DRSw2QkFvQ29DO0lBbkNwQyxrQ0FtQ29DO0lBbENwQyxxQ0FrQ29DO0lBakNwQyxnQ0FpQ29DO0lBaENwQyxpQ0FnQ29DO0lBQ3BDLFdBQVUsRUFBQSxFQUFBOztBQW5GVjtFQXdGRjtJQUNFLGdCQUFlO0lBQ2YsaUJBQWdCLEVBQUE7RUFFbEI7SUFDRSxnQkFBZTtJQUNmLGlCQUFnQixFQUFBO0VBRWxCO0lBQ0UsZ0JBQWU7SUFDZixpQkFDRixFQUFBO0VBQ0E7SUFDRSxnQkFBZTtJQUNmLGlCQUFnQixFQUFBO0VBRWxCO0lBQ0UsZ0JBQWU7SUFDZixpQkFBZ0IsRUFBQSxFQUFBOztBQTFGaEI7RUF3RUY7SUFDRSxnQkFBZTtJQUNmLGlCQUFnQixFQUFBO0VBRWxCO0lBQ0UsZ0JBQWU7SUFDZixpQkFBZ0IsRUFBQTtFQUVsQjtJQUNFLGdCQUFlO0lBQ2YsaUJBQ0YsRUFBQTtFQUNBO0lBQ0UsZ0JBQWU7SUFDZixpQkFBZ0IsRUFBQTtFQUVsQjtJQUNFLGdCQUFlO0lBQ2YsaUJBQWdCLEVBQUEsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3VzZXIvdXNlci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb2xvcntcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMzMkNEMzI7XHJcbn1cclxuXHJcbi8vIC5ib2R5e1xyXG4gXHJcbi8vICAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJ2h0dHBzOi8vbWRib290c3RyYXAuY29tL2ltZy9QaG90b3MvT3RoZXJzL2FyY2hpdGVjdHVyZS5qcGcnKTsgXHJcbi8vICAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4vLyAgICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbi8vICAgICAgIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlciBjZW50ZXI7XHJcbi8vIH1cclxuXHJcbiRwYXJ0aWNsZXM6IDUwO1xyXG4kd2lkdGg6IDUwMDtcclxuJGhlaWdodDogNTAwO1xyXG5cclxuLy8gQ3JlYXRlIHRoZSBleHBsb3Npb24uLi5cclxuJGJveC1zaGFkb3c6ICgpO1xyXG4kYm94LXNoYWRvdzI6ICgpO1xyXG5AZm9yICRpIGZyb20gMCB0aHJvdWdoICRwYXJ0aWNsZXMge1xyXG4gICRib3gtc2hhZG93OiAkYm94LXNoYWRvdyxcclxuICAgICAgICAgICAgICAgcmFuZG9tKCR3aWR0aCktJHdpZHRoIC8gMiArIHB4XHJcbiAgICAgICAgICAgICAgIHJhbmRvbSgkaGVpZ2h0KS0kaGVpZ2h0IC8gMS4yICsgcHhcclxuICAgICAgICAgICAgICAgaHNsKHJhbmRvbSgzNjApLCAxMDAsIDUwKTtcclxuICAkYm94LXNoYWRvdzI6ICRib3gtc2hhZG93MiwgMCAwICNmZmZcclxufVxyXG5AbWl4aW4ga2V5ZnJhbWVzICgkYW5pbWF0aW9uTmFtZSkge1xyXG4gICAgQC13ZWJraXQta2V5ZnJhbWVzICN7JGFuaW1hdGlvbk5hbWV9IHtcclxuICAgICAgICBAY29udGVudDtcclxuICAgIH1cclxuXHJcbiAgICBALW1vei1rZXlmcmFtZXMgI3skYW5pbWF0aW9uTmFtZX0ge1xyXG4gICAgICAgIEBjb250ZW50O1xyXG4gICAgfVxyXG5cclxuICAgIEAtby1rZXlmcmFtZXMgI3skYW5pbWF0aW9uTmFtZX0ge1xyXG4gICAgICAgIEBjb250ZW50O1xyXG4gICAgfVxyXG5cclxuICAgIEAtbXMta2V5ZnJhbWVzICN7JGFuaW1hdGlvbk5hbWV9IHtcclxuICAgICAgICBAY29udGVudDtcclxuICAgIH1cclxuXHJcbiAgICBAa2V5ZnJhbWVzICN7JGFuaW1hdGlvbk5hbWV9IHtcclxuICAgICAgICBAY29udGVudDtcclxuICAgIH1cclxufVxyXG5cclxuQG1peGluIGFuaW1hdGlvbi1kZWxheSAoJHNldHRpbmdzKSB7XHJcbiAgICAtbW96LWFuaW1hdGlvbi1kZWxheTogJHNldHRpbmdzO1xyXG4gICAgLXdlYmtpdC1hbmltYXRpb24tZGVsYXk6ICRzZXR0aW5ncztcclxuICAgIC1vLWFuaW1hdGlvbi1kZWxheTogJHNldHRpbmdzO1xyXG4gICAgLW1zLWFuaW1hdGlvbi1kZWxheTogJHNldHRpbmdzO1xyXG4gICAgYW5pbWF0aW9uLWRlbGF5OiAkc2V0dGluZ3M7XHJcbn1cclxuXHJcbkBtaXhpbiBhbmltYXRpb24tZHVyYXRpb24gKCRzZXR0aW5ncykge1xyXG4gICAgLW1vei1hbmltYXRpb24tZHVyYXRpb246ICRzZXR0aW5ncztcclxuICAgIC13ZWJraXQtYW5pbWF0aW9uLWR1cmF0aW9uOiAkc2V0dGluZ3M7XHJcbiAgICAtby1hbmltYXRpb24tZHVyYXRpb246ICRzZXR0aW5ncztcclxuICAgIC1tcy1hbmltYXRpb24tZHVyYXRpb246ICRzZXR0aW5ncztcclxuICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogJHNldHRpbmdzO1xyXG59XHJcblxyXG5AbWl4aW4gYW5pbWF0aW9uICgkc2V0dGluZ3MpIHtcclxuICAgIC1tb3otYW5pbWF0aW9uOiAkc2V0dGluZ3M7XHJcbiAgICAtd2Via2l0LWFuaW1hdGlvbjogJHNldHRpbmdzO1xyXG4gICAgLW8tYW5pbWF0aW9uOiAkc2V0dGluZ3M7XHJcbiAgICAtbXMtYW5pbWF0aW9uOiAkc2V0dGluZ3M7XHJcbiAgICBhbmltYXRpb246ICRzZXR0aW5ncztcclxufVxyXG5cclxuQG1peGluIHRyYW5zZm9ybSAoJHNldHRpbmdzKSB7XHJcbiAgICB0cmFuc2Zvcm06ICRzZXR0aW5ncztcclxuICAgIC1tb3otdHJhbnNmb3JtOiAkc2V0dGluZ3M7XHJcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogJHNldHRpbmdzO1xyXG4gICAgLW8tdHJhbnNmb3JtOiAkc2V0dGluZ3M7XHJcbiAgICAtbXMtdHJhbnNmb3JtOiAkc2V0dGluZ3M7XHJcbn1cclxuXHJcbmJvZHkge1xyXG4gIG1hcmdpbjowO1xyXG4gIHBhZGRpbmc6MDtcclxuICBiYWNrZ3JvdW5kOiAjMDAwO1xyXG4gIG92ZXJmbG93OiBoaWRkZW47XHJcbn1cclxuXHJcbi5weXJvID4gLmJlZm9yZSwgLnB5cm8gPiAuYWZ0ZXIge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB3aWR0aDogNXB4O1xyXG4gIGhlaWdodDogNXB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICBib3gtc2hhZG93OiAkYm94LXNoYWRvdzI7XHJcbiAgQGluY2x1ZGUgYW5pbWF0aW9uKCgxcyBiYW5nIGVhc2Utb3V0IGluZmluaXRlIGJhY2t3YXJkcywgMXMgZ3Jhdml0eSBlYXNlLWluIGluZmluaXRlIGJhY2t3YXJkcywgNXMgcG9zaXRpb24gbGluZWFyIGluZmluaXRlIGJhY2t3YXJkcykpO1xyXG59XHJcbiAgICBcclxuLnB5cm8gPiAuYWZ0ZXIge1xyXG4gIEBpbmNsdWRlIGFuaW1hdGlvbi1kZWxheSgoMS4yNXMsIDEuMjVzLCAxLjI1cykpO1xyXG4gIEBpbmNsdWRlIGFuaW1hdGlvbi1kdXJhdGlvbigoMS4yNXMsIDEuMjVzLCA2LjI1cykpO1xyXG59XHJcbiAgICAgICAgXHJcbkBpbmNsdWRlIGtleWZyYW1lcyhiYW5nKSB7XHJcbiAgdG8ge1xyXG4gICAgYm94LXNoYWRvdzokYm94LXNoYWRvdztcclxuICB9XHJcbn1cclxuICAgIFxyXG5AaW5jbHVkZSBrZXlmcmFtZXMoZ3Jhdml0eSkgIHtcclxuICB0byB7XHJcbiAgICBAaW5jbHVkZSB0cmFuc2Zvcm0odHJhbnNsYXRlWSgyMDBweCkpO1xyXG4gICAgb3BhY2l0eTogMDtcclxuICB9XHJcbn1cclxuICAgIFxyXG5AaW5jbHVkZSBrZXlmcmFtZXMocG9zaXRpb24pIHtcclxuICAwJSwgMTkuOSUge1xyXG4gICAgbWFyZ2luLXRvcDogMTAlO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDQwJTtcclxuICB9XHJcbiAgMjAlLCAzOS45JSB7XHJcbiAgICBtYXJnaW4tdG9wOiA0MCU7XHJcbiAgICBtYXJnaW4tbGVmdDogMzAlO1xyXG4gIH1cclxuICA0MCUsIDU5LjklIHsgIFxyXG4gICAgbWFyZ2luLXRvcDogMjAlO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDcwJVxyXG4gIH1cclxuICA2MCUsIDc5LjklIHsgIFxyXG4gICAgbWFyZ2luLXRvcDogMzAlO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDIwJTtcclxuICB9XHJcbiAgODAlLCA5OS45JSB7ICBcclxuICAgIG1hcmdpbi10b3A6IDMwJTtcclxuICAgIG1hcmdpbi1sZWZ0OiA4MCU7XHJcbiAgfVxyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/user/user.component.ts":
/*!****************************************!*\
  !*** ./src/app/user/user.component.ts ***!
  \****************************************/
/*! exports provided: UserComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserComponent", function() { return UserComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var UserComponent = /** @class */ (function () {
    function UserComponent() {
    }
    UserComponent.prototype.ngOnInit = function () {
    };
    UserComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-user',
            template: __webpack_require__(/*! ./user.component.html */ "./src/app/user/user.component.html"),
            styles: [__webpack_require__(/*! ./user.component.scss */ "./src/app/user/user.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], UserComponent);
    return UserComponent;
}());



/***/ }),

/***/ "./src/app/user/user.module.ts":
/*!*************************************!*\
  !*** ./src/app/user/user.module.ts ***!
  \*************************************/
/*! exports provided: UserModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserModule", function() { return UserModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _user_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./user.component */ "./src/app/user/user.component.ts");
/* harmony import */ var _admin_extral_admin_common_login_cookie__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../admin/extral-admin/common/login-cookie */ "./src/app/admin/extral-admin/common/login-cookie.ts");
/* harmony import */ var _trang_chu_menu_menu_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./trang-chu/menu/menu.component */ "./src/app/user/trang-chu/menu/menu.component.ts");
/* harmony import */ var _trang_chu_footer_footer_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./trang-chu/footer/footer.component */ "./src/app/user/trang-chu/footer/footer.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





// import { HomeUserModule } from './home-user/home-user.module';



var routing = [
    {
        path: '', component: _user_component__WEBPACK_IMPORTED_MODULE_4__["UserComponent"], children: [
            { path: 'trang-chu', loadChildren: './trang-chu/trang-chu.module#TrangChuModule' },
            { path: 'trang-khac', loadChildren: './trang-khac/trang-khac.module#TrangKhacModule' },
        ],
    },
];
var UserModule = /** @class */ (function () {
    function UserModule() {
    }
    UserModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            declarations: [
                _user_component__WEBPACK_IMPORTED_MODULE_4__["UserComponent"],
                _trang_chu_menu_menu_component__WEBPACK_IMPORTED_MODULE_6__["MenuComponent"],
                _trang_chu_footer_footer_component__WEBPACK_IMPORTED_MODULE_7__["FooterComponent"]
            ],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routing),
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
            ],
            entryComponents: [
                _user_component__WEBPACK_IMPORTED_MODULE_4__["UserComponent"],
            ],
            providers: [_admin_extral_admin_common_login_cookie__WEBPACK_IMPORTED_MODULE_5__["LoginCookie"]],
        })
    ], UserModule);
    return UserModule;
}());



/***/ })

}]);
//# sourceMappingURL=user-user-module.js.map