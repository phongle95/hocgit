(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["trang-chu-trang-chu-module"],{

/***/ "./src/app/user/trang-chu/danh-gia-khach/danh-gia-khach.component.html":
/*!*****************************************************************************!*\
  !*** ./src/app/user/trang-chu/danh-gia-khach/danh-gia-khach.component.html ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container wow bounceInDown\" data-wow-delay=\"0.3s\">\n  <div class=\"row\">\n    <div class=\"col\">\n      <img class=\"img-fluid\" src=\"http://thammy.vn/wp-content/themes/diemnhan/images/line-green.png\" width=\"100%px\"\n        height=\"100%px\" alt=\"Card image cap\">\n      <!-- Section: Testimonials v.2 -->\n      <section class=\"text-center my-5\">\n\n        <h2 class=\"h3-responsive text-center text-uppercase font-weight-bold my-5 \" style=\"color:#A65606\">đánh giá\n          khách hàng\n        </h2>\n        <!-- Carousel Wrapper -->\n        <div id=\"carousel-example-1\" class=\"carousel no-flex testimonial-carousel slide\" data-ride=\"carousel\">\n          <!--Slides-->\n          <div class=\"carousel-inner\" role=\"listbox\">\n            <!--First slide-->\n            <div class=\"carousel-item active\">\n              <div class=\"testimonial\">\n                <!--Avatar-->\n                <div class=\"avatar mx-auto mb-4\">\n                  <img src=\"https://www.vienthammykhothi.vn/public/img/khach-hang-02.png\" class=\"rounded-circle img-fluid\"\n                    alt=\"First sample avatar image\">\n                </div>\n                <!--Content-->\n                <p style=\"color:#A65606\">\n                  \" Phạm Tuấn An sinh năm 1989, là con trai trưởng trong một gia đình\n                  lao động như bao gia đình khác. An sinh ra có dáng dấp nhỏ nhắn nhưng khuôn mặt rất hiền và dễ gần.\n                  Thế nhưng, ngay từ nhỏ Tuấn An đã cảm thấy mình dường như “bị mắc kẹt” trong hình hài của một người\n                  con trai.\"\n                </p>\n                <div class=\"yellow-text text-center\">\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                </div>\n                <h2 class=\"h4-responsive text-center text-uppercase font-weight-bold my-5 \" style=\"color:#A65606\">câu\n                  chuyện thành công\n                </h2>\n                <!--Review-->\n\n              </div>\n            </div>\n            <!--First slide-->\n            <!--Second slide-->\n            <div class=\"carousel-item\">\n              <div class=\"testimonial\">\n                <!--Avatar-->\n                <div class=\"avatar mx-auto mb-4\">\n                  <img src=\"https://www.vienthammykhothi.vn/public/img/khach-hang.png\" class=\"rounded-circle img-fluid\"\n                    alt=\"Second sample avatar image\">\n                </div>\n                <!--Content-->\n                <p style=\"color:#A65606\">\n                  \"Cuộc sống của tôi đã thay đổi rất nhiều từ khi tôi quyết định phẩu thuật thẩm mỹ giờ đây tôi rất tự\n                  tin với vóc dáng như thế này công việc củng thuật lợi tiền tài củng đến nhiều hơn thật là một quyết\n                  định đúng đắng trong cuộc đời tôi cảm ơn bác sĩ đã phẩu thuật cho tôi \"\n                </p>\n                <div class=\"yellow-text text-center\">\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                </div>\n                <h2 class=\"h4-responsive text-center text-uppercase font-weight-bold my-5 \" style=\"color:#A65606\">câu\n                  chuyện thành công\n                </h2>\n                <!--Review-->\n\n              </div>\n            </div>\n            <!--Second slide-->\n\n          </div>\n          <!--Slides-->\n          <!--Controls-->\n          <a class=\"carousel-item-prev left carousel-control\" href=\"#carousel-example-1\" role=\"button\" data-slide=\"prev\">\n            <span class=\"icon-prev\" aria-hidden=\"true\"></span>\n            <span class=\"sr-only\">Previous</span>\n          </a>\n          <a class=\"carousel-item-next right carousel-control\" href=\"#carousel-example-1\" role=\"button\" data-slide=\"next\">\n            <span class=\"icon-next\" aria-hidden=\"true\"></span>\n            <span class=\"sr-only\">Next</span>\n          </a>\n          <!--Controls-->\n        </div>\n        <!-- Carousel Wrapper -->\n\n      </section>\n      <!-- Section: Testimonials v.2 -->\n    </div>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/user/trang-chu/danh-gia-khach/danh-gia-khach.component.scss":
/*!*****************************************************************************!*\
  !*** ./src/app/user/trang-chu/danh-gia-khach/danh-gia-khach.component.scss ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3VzZXIvdHJhbmctY2h1L2RhbmgtZ2lhLWtoYWNoL2RhbmgtZ2lhLWtoYWNoLmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/user/trang-chu/danh-gia-khach/danh-gia-khach.component.ts":
/*!***************************************************************************!*\
  !*** ./src/app/user/trang-chu/danh-gia-khach/danh-gia-khach.component.ts ***!
  \***************************************************************************/
/*! exports provided: DanhGiaKhachComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DanhGiaKhachComponent", function() { return DanhGiaKhachComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var DanhGiaKhachComponent = /** @class */ (function () {
    function DanhGiaKhachComponent() {
    }
    DanhGiaKhachComponent.prototype.ngOnInit = function () {
    };
    DanhGiaKhachComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-danh-gia-khach',
            template: __webpack_require__(/*! ./danh-gia-khach.component.html */ "./src/app/user/trang-chu/danh-gia-khach/danh-gia-khach.component.html"),
            styles: [__webpack_require__(/*! ./danh-gia-khach.component.scss */ "./src/app/user/trang-chu/danh-gia-khach/danh-gia-khach.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], DanhGiaKhachComponent);
    return DanhGiaKhachComponent;
}());



/***/ }),

/***/ "./src/app/user/trang-chu/dich-vu/dich-vu.component.html":
/*!***************************************************************!*\
  !*** ./src/app/user/trang-chu/dich-vu/dich-vu.component.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\">\r\n    <div class=\"row\">\r\n        <div class=\"col\">\r\n            <img class=\"img-fluid\" src=\"http://thammy.vn/wp-content/themes/diemnhan/images/line-green.png\" width=\"100%px\"\r\n                height=\"100%px\" alt=\"Card image cap\">\r\n            <h2 class=\"h3-responsive text-center text-uppercase font-weight-bold my-5 \" style=\"color:#A65606\">Dịch vụ\r\n                phù hợp với\r\n                bạn\r\n            </h2>\r\n            <div class=\"row\">\r\n                <div class=\"col-lg-3 col-md-12 mb-lg-0 mb-4 view overlay zoom\">\r\n                    <a routerLink=\"/user/trang-khac/my-pham\">\r\n                        <img class=\"img-fluid wow bounceInDown\" data-wow-delay=\"0.1s\" src=\"http://thammy.vn/wp-content/uploads/2018/11/cac-dich-vu-khac.png\"\r\n                            width=\"100%px\" height=\"100%px\" alt=\"Card image cap\">\r\n\r\n                        <p class=\"text\">\r\n                            <br>mỹ phẩm\r\n                        </p>\r\n                    </a>\r\n                </div>\r\n                <div class=\"col-lg-3 col-md-12 mb-lg-0 mb-4 view overlay zoom\">\r\n                    <a routerLink=\"/user/trang-khac/tham-my-khac\">\r\n                        <img class=\"img-fluid wow bounceInDown\" data-wow-delay=\"0.2s\" src=\"http://thammy.vn/wp-content/uploads/2018/11/tham-my-cong-nghe-cao.png\"\r\n                            width=\"100%px\" height=\"100%px\" alt=\"Card image cap\">\r\n\r\n                        <p class=\"text\">\r\n                            <br>thẩm mỹ khác\r\n                        </p>\r\n                    </a>\r\n                </div>\r\n                <div class=\"col-lg-3 col-md-12 mb-lg-0 mb-4 view overlay zoom\">\r\n                    <a routerLink=\"/user/trang-khac/phau-thuat-tham-my\">\r\n                        <img class=\"img-fluid wow bounceInDown\" data-wow-delay=\"0.3s\" src=\"http://thammy.vn/wp-content/uploads/2018/11/phau-thuat-tham-my.png\"\r\n                            width=\"100%px\" height=\"100%px\" alt=\"Card image cap\">\r\n\r\n                        <p class=\"text\">\r\n                            <br>phẩu thuật thẩm mỹ\r\n                        </p>\r\n                    </a>\r\n                </div>\r\n                <div class=\"col-lg-3 col-md-12 mb-lg-0 mb-4 view overlay zoom\">\r\n                    <a routerLink=\"/user/trang-khac/dieu-tri-da-spa\">\r\n                        <img class=\"img-fluid wow bounceInDown\" data-wow-delay=\"0.4s\" src=\"http://thammy.vn/wp-content/uploads/2018/11/cham-soc-da.png\"\r\n                            width=\"100%px\" height=\"100%px\" alt=\"Card image cap\">\r\n\r\n                        <p class=\"text\">\r\n                            <br>Điều trị da & spa\r\n                        </p>\r\n                    </a>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>"

/***/ }),

/***/ "./src/app/user/trang-chu/dich-vu/dich-vu.component.scss":
/*!***************************************************************!*\
  !*** ./src/app/user/trang-chu/dich-vu/dich-vu.component.scss ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".text {\n  text-align: center;\n  font-weight: 600;\n  color: #A65606;\n  font-size: 100%;\n  font-family: \"Helvetica\", Times, serif;\n  text-transform: uppercase; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlci90cmFuZy1jaHUvZGljaC12dS9DOlxceGFtcHBcXGh0ZG9jc1xcdGhhbV9teV92aWVuL3NyY1xcYXBwXFx1c2VyXFx0cmFuZy1jaHVcXGRpY2gtdnVcXGRpY2gtdnUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxtQkFBa0I7RUFDbEIsaUJBQWdCO0VBQ2hCLGVBQWU7RUFDZixnQkFBZTtFQUNmLHVDQUFzQztFQUN0QywwQkFBeUIsRUFDNUIiLCJmaWxlIjoic3JjL2FwcC91c2VyL3RyYW5nLWNodS9kaWNoLXZ1L2RpY2gtdnUuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudGV4dHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICBjb2xvcjogI0E2NTYwNiA7IFxyXG4gICAgZm9udC1zaXplOiAxMDAlO1xyXG4gICAgZm9udC1mYW1pbHk6IFwiSGVsdmV0aWNhXCIsIFRpbWVzLCBzZXJpZjtcclxuICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/user/trang-chu/dich-vu/dich-vu.component.ts":
/*!*************************************************************!*\
  !*** ./src/app/user/trang-chu/dich-vu/dich-vu.component.ts ***!
  \*************************************************************/
/*! exports provided: DichVuComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DichVuComponent", function() { return DichVuComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var DichVuComponent = /** @class */ (function () {
    function DichVuComponent() {
    }
    DichVuComponent.prototype.ngOnInit = function () {
    };
    DichVuComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-dich-vu',
            template: __webpack_require__(/*! ./dich-vu.component.html */ "./src/app/user/trang-chu/dich-vu/dich-vu.component.html"),
            styles: [__webpack_require__(/*! ./dich-vu.component.scss */ "./src/app/user/trang-chu/dich-vu/dich-vu.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], DichVuComponent);
    return DichVuComponent;
}());



/***/ }),

/***/ "./src/app/user/trang-chu/event/event.component.html":
/*!***********************************************************!*\
  !*** ./src/app/user/trang-chu/event/event.component.html ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container wow bounceInDown\" data-wow-delay=\"0.3s\">\n  <div class=\"row\">\n    <div class=\"col\">\n      <img class=\"img-fluid\" src=\"http://thammy.vn/wp-content/themes/diemnhan/images/line-green.png\" width=\"100%px\"\n        height=\"100%px\" alt=\"Card image cap\">\n\n\n      <!-- Section: Magazine v.2 -->\n      <section class=\"magazine-section my-5\">\n\n        <!-- Section heading -->\n        <h2 class=\"h3-responsive text-center text-uppercase font-weight-bold my-5 \" style=\"color:#A65606\">hoạn động -\n          sự kiện\n\n        </h2>\n\n\n        <!-- Grid row -->\n        <div class=\"row\">\n\n          <!-- Grid column -->\n          <div class=\"col-lg-6 col-md-12\">\n\n            <!-- Featured news -->\n            <div class=\"single-news mb-lg-0 mb-4\">\n\n              <!-- Image -->\n              <div class=\"view overlay rounded z-depth-1-half mb-4\">\n                <img class=\"img-fluid\" src=\"{{data.hinhAnh}}\" alt=\"Sample image\">\n                <a routerLink=\"/user/trang-khac/chi-tiet-tin-tuc/{{data.id}}\">\n                  <div class=\"mask rgba-white-slight\"></div>\n                </a>\n              </div>\n\n              <!-- Data -->\n              <div class=\"news-data d-flex justify-content-between\">\n                <a routerLink=\"/user/trang-khac/chi-tiet-tin-tuc/{{data.id}}\" class=\"deep-orange-text\">\n                  <h6 class=\"font-weight-bold\">new <i class=\"fa fa-angle-double-right fa-1x deep-orange-text\"></i> </h6>\n                </a>\n                <p class=\"font-weight-bold dark-grey-text\">{{data.ngayDang}}<img class=\"img-fluid\" src=\"http://caytrongduoclieu.com/asset/image/hot.gif\" alt=\"Sample image\"></p>\n              </div>\n\n              <!-- Excerpt -->\n              <h4 class=\"font-weight-bold dark-grey-text mb-3\"><a> {{data.tieuDe}}</a></h4>\n              <p class=\"font-weight-normal mb-lg-0 mb-md-5 mb-4\">{{data.tomTat}}</p>\n\n            </div>\n            <!-- Featured news -->\n\n          </div>\n          <!-- Grid column -->\n\n          <!-- Grid column -->\n          <div class=\"col-lg-6 col-md-12\">\n\n            <div *ngFor=\"let news of listNews\">\n\n              <!-- Small news -->\n              <div class=\"single-news mb-4\">\n\n                <!-- Grid row -->\n                <div class=\"row\">\n\n                  <!-- Grid column -->\n                  <div class=\"col-md-3\">\n\n                    <!--Image-->\n                    <div class=\"view overlay rounded z-depth-1 mb-4\">\n                      <img class=\"img-fluid\" src=\"{{news.hinhAnh}}\" alt=\"Sample image\">\n                      <a routerLink=\"/user/trang-khac/chi-tiet-tin-tuc/{{news.id}}\">\n                        <div class=\"mask rgba-white-slight\"></div>\n                      </a>\n                    </div>\n\n                  </div>\n                  <!-- Grid column -->\n\n                  <!-- Grid column -->\n                  <div class=\"col-md-9\">\n\n                    <!-- Excerpt -->\n                    <p class=\"font-weight-bold dark-grey-text\">{{news.ngayDang}} <img class=\"img-fluid\" src=\"http://caytrongduoclieu.com/asset/image/hot.gif\" alt=\"Sample image\"></p>\n                    <div class=\"d-flex justify-content-between\">\n                      <div class=\"col-11 text-truncate pl-0 mb-3\">\n                        <a routerLink=\"/user/trang-khac/chi-tiet-tin-tuc/{{news.id}}\" class=\"dark-grey-text\">{{news.tieuDe}}</a>\n                      </div>\n                      <a routerLink=\"/user/trang-khac/chi-tiet-tin-tuc/{{news.id}}\"> <i class=\"fa fa-angle-double-right fa-1x deep-orange-text\"></i></a>\n                    </div>\n\n                  </div>\n                  <!-- Grid column -->\n\n                </div>\n                <!-- Grid row -->\n\n              </div>\n              <!-- Small news -->\n              <hr>\n            </div>\n\n            <iframe src=\"https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Ffacebook&tabs&width=400&height=214&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId\"\n              width=\"330\" height=\"214\" style=\"border:none;overflow:hidden\" scrolling=\"no\" frameborder=\"0\"\n              allowTransparency=\"true\" allow=\"encrypted-media\"></iframe>\n\n          </div>\n          <!--Grid column-->\n\n        </div>\n        <!-- Grid row -->\n\n      </section>\n      <!-- Section: Magazine v.2 -->\n    </div>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/user/trang-chu/event/event.component.scss":
/*!***********************************************************!*\
  !*** ./src/app/user/trang-chu/event/event.component.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3VzZXIvdHJhbmctY2h1L2V2ZW50L2V2ZW50LmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/user/trang-chu/event/event.component.ts":
/*!*********************************************************!*\
  !*** ./src/app/user/trang-chu/event/event.component.ts ***!
  \*********************************************************/
/*! exports provided: EventComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EventComponent", function() { return EventComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var src_app_api_thammyvien_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/api/thammyvien.service */ "./src/app/api/thammyvien.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var EventComponent = /** @class */ (function () {
    function EventComponent(thamMyVienService) {
        this.thamMyVienService = thamMyVienService;
    }
    EventComponent.prototype.ngOnInit = function () {
        this.getNews1();
        this.getNews4();
    };
    // lay 1 tin moi nhat
    EventComponent.prototype.getNews1 = function () {
        var _this = this;
        this.thamMyVienService.excuteAllByWhat({}, '15')
            .subscribe(function (data) {
            _this.data = data[0];
            // console.log('phogn',this.data);
        });
    };
    // lay 4 tin moi nhat
    EventComponent.prototype.getNews4 = function () {
        var _this = this;
        this.thamMyVienService.excuteAllByWhat({}, '16')
            .subscribe(function (data) {
            _this.listNews = data;
            console.log('phogn', _this.listNews);
        });
    };
    EventComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-event',
            template: __webpack_require__(/*! ./event.component.html */ "./src/app/user/trang-chu/event/event.component.html"),
            styles: [__webpack_require__(/*! ./event.component.scss */ "./src/app/user/trang-chu/event/event.component.scss")]
        }),
        __metadata("design:paramtypes", [src_app_api_thammyvien_service__WEBPACK_IMPORTED_MODULE_1__["ThamMyVienService"]])
    ], EventComponent);
    return EventComponent;
}());



/***/ }),

/***/ "./src/app/user/trang-chu/image/image.component.html":
/*!***********************************************************!*\
  !*** ./src/app/user/trang-chu/image/image.component.html ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container wow fadeInDown\" data-wow-delay=\"0.3s\">\n  <img class=\"img-fluid\" src=\"http://thammy.vn/wp-content/themes/diemnhan/images/line-green.png\" width=\"100%px\" height=\"100%px\"\n    alt=\"Card image cap\">\n  <div class=\"row\">\n    <div class=\"col\">\n      <h2 class=\"h3-responsive text-center text-uppercase font-weight-bold my-5 \" style=\"color:#A65606\">Người nổi tiếng</h2>\n      <!--Carousel Wrapper-->\n      <div id=\"multi-item-example\" class=\"carousel slide carousel-multi-item\" data-ride=\"carousel\">\n\n        <!--Controls-->\n        <div class=\"controls-top\">\n          <a class=\"btn-floating\" href=\"#multi-item-example\" data-slide=\"prev\">\n            <i class=\"fa fa-chevron-left fa-1x white-text\"></i>\n          </a>\n          <a class=\"btn-floating\" href=\"#multi-item-example\" data-slide=\"next\">\n            <i class=\"fa fa-chevron-right fa-1x white-text\"></i>\n          </a>\n        </div>\n        <!--/.Controls-->\n\n        <!--Indicators-->\n        <ol class=\"carousel-indicators\">\n          <li data-target=\"#multi-item-example\" data-slide-to=\"0\" class=\"active\"></li>\n          <li data-target=\"#multi-item-example\" data-slide-to=\"1\"></li>\n          <li data-target=\"#multi-item-example\" data-slide-to=\"2\"></li>\n        </ol>\n        <!--/.Indicators-->\n\n        <!--Slides-->\n        <div class=\"carousel-inner\" role=\"listbox\">\n\n          <!--First slide-->\n          <div class=\"carousel-item active\">\n\n            <div class=\"col-md-4\">\n              <div class=\"mb-2\">\n                <img class=\"card-img-top rounded-circle img-fluid\" src=\"https://www.vienthammykhothi.vn/upload/source/khach-hang/user-y-lan.png\"\n                  alt=\"Card image cap\">\n                <div class=\"yellow-text text-center\">\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                </div>\n                <h6 class=\"text-center font-weight-bold my-3\" style=\"color:#A65606\">Danh ca Ý Lan</h6>\n\n                <p class=\" text-center font-weight-normal\">\n                  Dịch vụ Uthera lonic</p>\n              </div>\n            </div>\n\n            <div class=\"col-md-4 clearfix d-none d-md-block\">\n              <div class=\" mb-2\">\n                <img class=\"card-img-top\" src=\"https://www.vienthammykhothi.vn/upload/source/khach-hang/user-thanhloc.png\"\n                  alt=\"Card image cap\">\n                <div class=\"yellow-text text-center\">\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                </div>\n                <h6 class=\"text-center font-weight-bold my-3\" style=\"color:#A65606\">Diển viên Thành Lộc</h6>\n                <p class=\" text-center font-weight-normal\">\n                  Dịch vụ căn da bằng chì</p>\n              </div>\n            </div>\n\n            <div class=\"col-md-4 clearfix d-none d-md-block\">\n              <div class=\" mb-2\">\n                <img class=\"card-img-top\" src=\"https://www.vienthammykhothi.vn/upload/source/khach-hang/user-duongtrieuvu.png\"\n                  alt=\"Card image cap\">\n                  <div class=\"yellow-text text-center\">\n                    <i class=\"fa fa-star\"> </i>\n                    <i class=\"fa fa-star\"> </i>\n                    <i class=\"fa fa-star\"> </i>\n                    <i class=\"fa fa-star\"> </i>\n                    <i class=\"fa fa-star\"> </i>\n                  </div>\n                <h6 class=\"text-center font-weight-bold my-3\" style=\"color:#A65606\">Dương Triệu Vũ</h6>\n                <p class=\" text-center font-weight-normal\">\n                  Cấy tóc tự thân Hair Balance</p>\n              </div>\n            </div>\n\n\n          </div>\n          <!--/.First slide-->\n\n          <!--Second slide-->\n          <div class=\"carousel-item\">\n\n            <div class=\"col-md-4\">\n              <div class=\"mb-2\">\n                <img class=\"card-img-top rounded-circle img-fluid\" src=\"https://www.vienthammykhothi.vn/upload/source/khach-hang/user-kunny.png\"\n                  alt=\"Card image cap\">\n                <div class=\"yellow-text text-center\">\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                </div>\n                <h6 class=\"text-center font-weight-bold my-3\" style=\"color:#A65606\">Kuny Lee</h6>\n                <p class=\" text-center font-weight-normal\">\n                  Cấy tóc tự thân Hair Balance</p>\n              </div>\n            </div>\n\n            <div class=\"col-md-4 clearfix d-none d-md-block\">\n              <div class=\" mb-2\">\n                <img class=\"card-img-top\" src=\"https://www.vienthammykhothi.vn/upload/source/khach-hang/user-ductien.png\"\n                  alt=\"Card image cap\">\n                <div class=\"yellow-text text-center\">\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                </div>\n                <h6 class=\"text-center font-weight-bold my-3\" style=\"color:#A65606\">Diển viên Đức Tiến</h6>\n                <p class=\" text-center font-weight-normal\">\n                  Cấy tóc tự thân Hair Balance</p>\n              </div>\n            </div>\n\n            <div class=\"col-md-4 clearfix d-none d-md-block\">\n              <div class=\" mb-2\">\n                <img class=\"card-img-top\" src=\"https://www.vienthammykhothi.vn/upload/source/khach-hang/user-thuydung.png\"\n                  alt=\"Card image cap\">\n                <div class=\"yellow-text text-center\">\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                </div>\n                <h6 class=\"text-center font-weight-bold my-3\" style=\"color:#A65606\">Hoa hậu 2008 Thùy Dung</h6>\n                <p class=\" text-center font-weight-normal\">\n                  Công nghệ tắm trắng bạch ngọc thể</p>\n              </div>\n            </div>\n\n\n          </div>\n          <!--/.Second slide-->\n\n          <!--Third slide-->\n          <div class=\"carousel-item\">\n\n\n            <div class=\"col-md-4\">\n              <div class=\"mb-2\">\n                <img class=\"card-img-top rounded-circle img-fluid\" src=\"https://www.vienthammykhothi.vn/upload/source/khach-hang/user-donnguyen.png\"\n                  alt=\"Card image cap\">\n                <div class=\"yellow-text text-center\">\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                </div>\n                <h6 class=\"text-center font-weight-bold my-3\" style=\"color:#A65606\">Diển viên Don Nguyễn</h6>\n                <p class=\" text-center font-weight-normal\">\n                  Dảm cân D-OTESALYCOOLS</p>\n              </div>\n            </div>\n\n            <div class=\"col-md-4 clearfix d-none d-md-block\">\n              <div class=\" mb-2\">\n                <img class=\"card-img-top\" src=\"https://www.vienthammykhothi.vn/upload/source/khach-hang/user-khanhngan.png\"\n                  alt=\"Card image cap\">\n                <div class=\"yellow-text text-center\">\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                </div>\n                <h6 class=\"text-center font-weight-bold my-3\" style=\"color:#A65606\">Hoa hậu hoàn cầu Khánh Ngân</h6>\n                <p class=\" text-center font-weight-normal\">\n                  Thủy quan Titan</p>\n              </div>\n            </div>\n\n            <div class=\"col-md-4 clearfix d-none d-md-block\">\n              <div class=\" mb-2\">\n                <img class=\"card-img-top\" src=\"https://www.vienthammykhothi.vn/upload/source/khach-hang/user-chunghuyenthanh.png\"\n                  alt=\"Card image cap\">\n                <div class=\"yellow-text text-center\">\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                  <i class=\"fa fa-star\"> </i>\n                </div>\n                <h6 class=\"text-center font-weight-bold my-3\" style=\"color:#A65606\">Chúng Huyền Thanh</h6>\n                <p class=\" text-center font-weight-normal\">\n                  Dịch vụ giảm cân</p>\n              </div>\n            </div>\n\n\n          </div>\n          <!--/.Slides-->\n\n        </div>\n        <!--/.Carousel Wrapper-->\n      </div>\n    </div>\n  </div>"

/***/ }),

/***/ "./src/app/user/trang-chu/image/image.component.scss":
/*!***********************************************************!*\
  !*** ./src/app/user/trang-chu/image/image.component.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".color {\n  background-color: #A65606; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlci90cmFuZy1jaHUvaW1hZ2UvQzpcXHhhbXBwXFxodGRvY3NcXHRoYW1fbXlfdmllbi9zcmNcXGFwcFxcdXNlclxcdHJhbmctY2h1XFxpbWFnZVxcaW1hZ2UuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSwwQkFBeUIsRUFDNUIiLCJmaWxlIjoic3JjL2FwcC91c2VyL3RyYW5nLWNodS9pbWFnZS9pbWFnZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb2xvcntcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNBNjU2MDY7XHJcbn1cclxuXHJcbi8vIC5pbWd7XHJcbi8vICAgICB3aWR0aDogNTAwcHg7XHJcbi8vICAgICBoZWlnaHQ6IDMwMHB4O1xyXG4vLyB9Il19 */"

/***/ }),

/***/ "./src/app/user/trang-chu/image/image.component.ts":
/*!*********************************************************!*\
  !*** ./src/app/user/trang-chu/image/image.component.ts ***!
  \*********************************************************/
/*! exports provided: ImageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImageComponent", function() { return ImageComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var ImageComponent = /** @class */ (function () {
    function ImageComponent() {
    }
    ImageComponent.prototype.ngOnInit = function () {
    };
    ImageComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-image',
            template: __webpack_require__(/*! ./image.component.html */ "./src/app/user/trang-chu/image/image.component.html"),
            styles: [__webpack_require__(/*! ./image.component.scss */ "./src/app/user/trang-chu/image/image.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], ImageComponent);
    return ImageComponent;
}());



/***/ }),

/***/ "./src/app/user/trang-chu/intro/intro.component.html":
/*!***********************************************************!*\
  !*** ./src/app/user/trang-chu/intro/intro.component.html ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\">\n  <div class=\"row\">\n    <div class=\"col\">\n      <img class=\"img-fluid\" src=\"http://thammy.vn/wp-content/themes/diemnhan/images/line-green.png\" width=\"100%px\"\n        height=\"100%px\" alt=\"Card image cap\">\n      <div class=\"row\">\n        <div class=\"col-lg-6 col-md-12 mb-lg-0 mb-4 wow bounceInLeft system view hm-zoom desk\" data-wow-delay=\"0.3s\">\n          <p class=\"text\">\n            \"Thành công luôn đồng hành cùng nhan sắt hoàn hảo! vinass luôn mang đến cho bạn sự đẳng cấp cũng như chất\n            lượng dịch vụ\n            tốt nhất từ trang thiết bị đến đội ngũ bác sỹ và nhân viên phục vụ\"\n          </p>\n\n        </div>\n        <div class=\"col-lg-6 col-md-12 mb-lg-0 mb-4 view overlay zoom\">\n          <div class=\" wow bounceInRight system view hm-zoom desk\" data-wow-delay=\"0.3s\">\n            <img class=\"img-fluid\" src=\"https://thammyhanquoc.vn/wp-content/themes/jw-zw/ldpage-parts/lp/12_2018/lp_tet/images/p1-main.png\"\n              alt=\"Card image cap\">\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/user/trang-chu/intro/intro.component.scss":
/*!***********************************************************!*\
  !*** ./src/app/user/trang-chu/intro/intro.component.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@media (min-width: 1199.98px) {\n  .text {\n    color: #A65606;\n    text-align: center;\n    font-size: 23px;\n    padding-top: 150px;\n    font-weight: 400;\n    font-family: \"Helvetica\", Times, serif; }\n  .center:hover {\n    background-color: #A65606;\n    color: white; } }\n\n@media (max-width: 1199.98px) {\n  .text {\n    color: #A65606;\n    text-align: center;\n    font-size: 23px;\n    padding-top: 10px;\n    font-weight: 400;\n    font-family: \"Helvetica\", Times, serif; } }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlci90cmFuZy1jaHUvaW50cm8vQzpcXHhhbXBwXFxodGRvY3NcXHRoYW1fbXlfdmllbi9zcmNcXGFwcFxcdXNlclxcdHJhbmctY2h1XFxpbnRyb1xcaW50cm8uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFFSTtJQUNJLGVBQWM7SUFDZCxtQkFBa0I7SUFDbEIsZ0JBQWU7SUFDZixtQkFBa0I7SUFDbEIsaUJBQWdCO0lBQ2hCLHVDQUFzQyxFQUV6QztFQUNEO0lBQ0ksMEJBQXlCO0lBQ3pCLGFBQVksRUFDZixFQUFBOztBQUlMO0VBRUk7SUFDSSxlQUFjO0lBQ2QsbUJBQWtCO0lBQ2xCLGdCQUFlO0lBQ2Ysa0JBQWlCO0lBQ2pCLGlCQUFnQjtJQUNoQix1Q0FBc0MsRUFFekMsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3VzZXIvdHJhbmctY2h1L2ludHJvL2ludHJvLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbkBtZWRpYSAobWluLXdpZHRoOiAxMTk5Ljk4cHgpIHtcclxuXHJcbiAgICAudGV4dHtcclxuICAgICAgICBjb2xvcjogI0E2NTYwNjtcclxuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgZm9udC1zaXplOiAyM3B4O1xyXG4gICAgICAgIHBhZGRpbmctdG9wOiAxNTBweDtcclxuICAgICAgICBmb250LXdlaWdodDogNDAwO1xyXG4gICAgICAgIGZvbnQtZmFtaWx5OiBcIkhlbHZldGljYVwiLCBUaW1lcywgc2VyaWY7XHJcbiAgICBcclxuICAgIH1cclxuICAgIC5jZW50ZXI6aG92ZXJ7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI0E2NTYwNjtcclxuICAgICAgICBjb2xvcjogd2hpdGU7XHJcbiAgICB9XHJcbn1cclxuXHJcblxyXG5AbWVkaWEgKG1heC13aWR0aDogMTE5OS45OHB4KSB7XHJcblxyXG4gICAgLnRleHR7XHJcbiAgICAgICAgY29sb3I6ICNBNjU2MDY7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMjNweDtcclxuICAgICAgICBwYWRkaW5nLXRvcDogMTBweDtcclxuICAgICAgICBmb250LXdlaWdodDogNDAwO1xyXG4gICAgICAgIGZvbnQtZmFtaWx5OiBcIkhlbHZldGljYVwiLCBUaW1lcywgc2VyaWY7XHJcbiAgICBcclxuICAgIH1cclxufVxyXG5cclxuIl19 */"

/***/ }),

/***/ "./src/app/user/trang-chu/intro/intro.component.ts":
/*!*********************************************************!*\
  !*** ./src/app/user/trang-chu/intro/intro.component.ts ***!
  \*********************************************************/
/*! exports provided: IntroComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IntroComponent", function() { return IntroComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var IntroComponent = /** @class */ (function () {
    function IntroComponent() {
    }
    IntroComponent.prototype.ngOnInit = function () {
    };
    IntroComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-intro',
            template: __webpack_require__(/*! ./intro.component.html */ "./src/app/user/trang-chu/intro/intro.component.html"),
            styles: [__webpack_require__(/*! ./intro.component.scss */ "./src/app/user/trang-chu/intro/intro.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], IntroComponent);
    return IntroComponent;
}());



/***/ }),

/***/ "./src/app/user/trang-chu/slide/slide.component.html":
/*!***********************************************************!*\
  !*** ./src/app/user/trang-chu/slide/slide.component.html ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<br><br><br>\n<div id=\"carouselExampleIndicators\" class=\"carousel slide \" data-ride=\"carousel\">\n  <ol class=\"carousel-indicators\">\n    <li data-target=\"#carouselExampleIndicators\" data-slide-to=\"0\" class=\"active\"></li>\n    <li data-target=\"#carouselExampleIndicators\" data-slide-to=\"1\"></li>\n    <li data-target=\"#carouselExampleIndicators\" data-slide-to=\"2\"></li>\n    <li data-target=\"#carouselExampleIndicators\" data-slide-to=\"3\"></li>\n  </ol>\n  <div class=\"carousel-inner \">\n    <div class=\"carousel-item active\">\n      <img class=\"d-block w-100 custom-slide\" src=\"http://thammy.vn/wp-content/uploads/2018/12/banner-webhydra.jpg\" alt=\"Salem Piano\">\n\n\n\n    </div>\n    <div class=\"carousel-item\">\n      <img class=\"d-block w-100 custom-slide\" src=\"http://thammy.vn/wp-content/uploads/2018/11/Laser-Q-Switch.png\" alt=\"Salem Piano\">\n\n    </div>\n    <div class=\"carousel-item\">\n      <img class=\"d-block w-100 custom-slide\" src=\"http://thammy.vn/wp-content/uploads/2018/11/banner-cat-mi-mat.jpg\"\n        alt=\"Salem Piano\">\n\n    </div>\n    <div class=\"carousel-item\">\n      <img class=\"d-block w-100 custom-slide\" src=\"http://thammy.vn/wp-content/uploads/2018/11/Side-web-skincare.png\"\n        alt=\"Salem Piano\">\n    </div>\n\n  </div>\n  <a class=\"carousel-control-prev\" href=\"#carouselExampleIndicators\" role=\"button\" data-slide=\"prev\">\n    <i class=\"fa fa-angle-double-left fa-3x white-text\"></i>\n    <span class=\"sr-only\">Previous</span>\n  </a>\n  <a class=\"carousel-control-next\" href=\"#carouselExampleIndicators\" role=\"button\" data-slide=\"next\">\n    <i class=\"fa fa-angle-double-right fa-3x white-text\"></i>\n    <span class=\"sr-only\">Next</span>\n  </a>\n</div>"

/***/ }),

/***/ "./src/app/user/trang-chu/slide/slide.component.scss":
/*!***********************************************************!*\
  !*** ./src/app/user/trang-chu/slide/slide.component.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".caption {\n  font-weight: 500;\n  font-size: 110%;\n  font-family: \"Helvetica\", Times, serif;\n  color: white;\n  text-shadow: 40px;\n  padding-left: 10px;\n  margin-top: 20%; }\n\n@media (max-width: 1199.98px) {\n  .custom-slide {\n    height: 200px;\n    width: 100%; }\n  .slide-caption {\n    padding-left: 10px;\n    margin-top: 10px;\n    font-size: 12px;\n    font-family: \"Helvetica\", Times, serif;\n    line-height: 1.4;\n    height: 130px;\n    width: 240px;\n    background-color: rgba(62, 69, 81, 0.7); } }\n\n@media (min-width: 1199.98px) {\n  .slide-caption {\n    font-family: \"Helvetica\", Times, serif;\n    font-weight: 370;\n    padding-left: 20px;\n    padding-right: 20px;\n    height: 200px;\n    font-size: 17px;\n    width: 420px;\n    background-color: rgba(62, 69, 81, 0.7); }\n  .caption1 {\n    padding-top: 20px; } }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlci90cmFuZy1jaHUvc2xpZGUvQzpcXHhhbXBwXFxodGRvY3NcXHRoYW1fbXlfdmllbi9zcmNcXGFwcFxcdXNlclxcdHJhbmctY2h1XFxzbGlkZVxcc2xpZGUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBSUE7RUFDSSxpQkFBZ0I7RUFDaEIsZ0JBQWU7RUFDZix1Q0FBc0M7RUFDdEMsYUFBWTtFQUNaLGtCQUFpQjtFQUNqQixtQkFBa0I7RUFDbEIsZ0JBQWUsRUFDbEI7O0FBRUQ7RUFFRTtJQUNFLGNBQWE7SUFDYixZQUFXLEVBQ1o7RUFFSDtJQUNFLG1CQUFrQjtJQUVsQixpQkFBZ0I7SUFDaEIsZ0JBQWU7SUFDZix1Q0FBc0M7SUFDdEMsaUJBQWdCO0lBSWhCLGNBQWE7SUFDYixhQUFZO0lBQ1osd0NBQXNDLEVBQ3ZDLEVBQUE7O0FBSUQ7RUFHQTtJQUNFLHVDQUFzQztJQUN0QyxpQkFBZ0I7SUFDaEIsbUJBQWtCO0lBQ2xCLG9CQUFtQjtJQUNuQixjQUFhO0lBQ2IsZ0JBQWU7SUFDZixhQUFZO0lBQ1osd0NBQXNDLEVBQ3ZDO0VBQ0Q7SUFDRSxrQkFBaUIsRUFFbEIsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3VzZXIvdHJhbmctY2h1L3NsaWRlL3NsaWRlLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gLmN1c3RvbS1pbWFnZXtcclxuLy8gICAgIGhlaWdodDogNjUwcHg7XHJcbi8vICAgICB3aWR0aDogNTAlO1xyXG4vLyB9XHJcbi5jYXB0aW9ue1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgIGZvbnQtc2l6ZTogMTEwJTtcclxuICAgIGZvbnQtZmFtaWx5OiBcIkhlbHZldGljYVwiLCBUaW1lcywgc2VyaWY7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICB0ZXh0LXNoYWRvdzogNDBweDtcclxuICAgIHBhZGRpbmctbGVmdDogMTBweDtcclxuICAgIG1hcmdpbi10b3A6IDIwJTtcclxufVxyXG5cclxuQG1lZGlhIChtYXgtd2lkdGg6IDExOTkuOThweCkge1xyXG5cclxuICAuY3VzdG9tLXNsaWRle1xyXG4gICAgaGVpZ2h0OiAyMDBweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gIH1cclxuICAgIFxyXG4uc2xpZGUtY2FwdGlvbntcclxuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XHJcbiAgLy8gcGFkZGluZy10b3A6IDFweDtcclxuICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gIGZvbnQtc2l6ZTogMTJweDtcclxuICBmb250LWZhbWlseTogXCJIZWx2ZXRpY2FcIiwgVGltZXMsIHNlcmlmO1xyXG4gIGxpbmUtaGVpZ2h0OiAxLjQ7XHJcbiAgLy8gaGVpZ2h0OiAyNTBweDtcclxuICAvLyB3aWR0aDogNDAwcHg7XHJcbiAgLy8gYmFja2dyb3VuZC1jb2xvcjpyZ2JhKDYyLCA2OSwgODEsIDAuNyk7XHJcbiAgaGVpZ2h0OiAxMzBweDtcclxuICB3aWR0aDogMjQwcHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjpyZ2JhKDYyLCA2OSwgODEsIDAuNyk7XHJcbn1cclxuIFxyXG59XHJcblxyXG5AbWVkaWEgKG1pbi13aWR0aDogMTE5OS45OHB4KSB7XHJcblxyXG4gIFxyXG4uc2xpZGUtY2FwdGlvbntcclxuICBmb250LWZhbWlseTogXCJIZWx2ZXRpY2FcIiwgVGltZXMsIHNlcmlmO1xyXG4gIGZvbnQtd2VpZ2h0OiAzNzA7XHJcbiAgcGFkZGluZy1sZWZ0OiAyMHB4O1xyXG4gIHBhZGRpbmctcmlnaHQ6IDIwcHg7XHJcbiAgaGVpZ2h0OiAyMDBweDtcclxuICBmb250LXNpemU6IDE3cHg7XHJcbiAgd2lkdGg6IDQyMHB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6cmdiYSg2MiwgNjksIDgxLCAwLjcpO1xyXG59XHJcbi5jYXB0aW9uMXtcclxuICBwYWRkaW5nLXRvcDogMjBweDtcclxuXHJcbn1cclxufVxyXG5cclxuXHJcbi8vIC5jdXN0b20tc2xpZGV7XHJcbi8vICAgICBoZWlnaHQ6IDExMDBweDtcclxuLy8gfSJdfQ== */"

/***/ }),

/***/ "./src/app/user/trang-chu/slide/slide.component.ts":
/*!*********************************************************!*\
  !*** ./src/app/user/trang-chu/slide/slide.component.ts ***!
  \*********************************************************/
/*! exports provided: SlideComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SlideComponent", function() { return SlideComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var SlideComponent = /** @class */ (function () {
    function SlideComponent() {
    }
    SlideComponent.prototype.ngOnInit = function () {
    };
    SlideComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-slide',
            template: __webpack_require__(/*! ./slide.component.html */ "./src/app/user/trang-chu/slide/slide.component.html"),
            styles: [__webpack_require__(/*! ./slide.component.scss */ "./src/app/user/trang-chu/slide/slide.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], SlideComponent);
    return SlideComponent;
}());



/***/ }),

/***/ "./src/app/user/trang-chu/trang-chu.component.html":
/*!*********************************************************!*\
  !*** ./src/app/user/trang-chu/trang-chu.component.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- <img class=\"img-fluid\" src=\"https://ngomonghung.net/wp-content/themes/Newspaper/images/baikhuyenmai/long/banner/banner.jpg\" width=\"100%px\" height=\"100%px\" alt=\"Card image cap\"> -->\r\n<app-slide></app-slide>\r\n\r\n<app-intro></app-intro>\r\n<app-image></app-image>\r\n<app-dich-vu></app-dich-vu>\r\n<app-event></app-event>\r\n<app-danh-gia-khach></app-danh-gia-khach>"

/***/ }),

/***/ "./src/app/user/trang-chu/trang-chu.component.scss":
/*!*********************************************************!*\
  !*** ./src/app/user/trang-chu/trang-chu.component.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".sidebar-fixed {\n  height: 100vh;\n  width: 270px;\n  box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.16), 0 2px 10px 0 rgba(0, 0, 0, 0.12);\n  z-index: 1050;\n  background-color: #fff;\n  padding: 1.5rem;\n  padding-top: 0; }\n\n.sidebar-fixed .list-group .active {\n  box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.16), 0 2px 10px 0 rgba(0, 0, 0, 0.12);\n  border-radius: 5px; }\n\n.sidebar-fixed .logo-wrapper {\n  padding: 2.5rem; }\n\n.sidebar-fixed .logo-wrapper img {\n  max-height: 50px; }\n\n@media (min-width: 1200px) {\n  .navbar,\n  .page-footer,\n  main {\n    padding-left: 270px; } }\n\n@media (max-width: 1199.98px) {\n  .sidebar-fixed {\n    display: none; } }\n\n/* custom tree styles */\n\n.custom-card {\n  width: 300px;\n  float: left;\n  padding-bottom: 500px;\n  margin-right: 352px;\n  position: fixed; }\n\n/* custom tree styles */\n\n.custom-tree.wj-treeview {\n  color: #5c6bc0;\n  padding-top: 35px;\n  font-size: 75%;\n  font-family: \"Helvetica\", Times, serif;\n  font-weight: 600; }\n\n/* level 0 and deeper nodes */\n\n.custom-tree.wj-treeview .wj-nodelist > .wj-node {\n  font-size: 100%; }\n\n/* level 1 and deeper nodes (larger font, vertical line along the left) */\n\n.custom-tree.wj-treeview .wj-nodelist > .wj-nodelist > .wj-node,\n.custom-tree.wj-treeview .wj-nodelist > .wj-nodelist > .wj-nodelist {\n  font-size: 100%;\n  border-left: 4px solid rgba(128, 4, 77, 0.3); }\n\n/* level 2 and deeper nodes (smaller font, thinner border) */\n\n.custom-tree.wj-treeview .wj-nodelist > .wj-nodelist > .wj-nodelist > .wj-node,\n.custom-tree.wj-treeview .wj-nodelist > .wj-nodelist > .wj-nodelist > .wj-nodelist {\n  font-size: 100%;\n  border-left: 2px solid rgba(128, 4, 77, 0.3); }\n\n/* expanded node glyph */\n\n.custom-tree.wj-treeview .wj-nodelist .wj-node:before {\n  content: \"\\e114\";\n  font-family: 'Glyphicons Halflings';\n  top: 4px;\n  border: none;\n  opacity: .3;\n  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); }\n\n/* collapsed node glyph */\n\n.custom-tree.wj-treeview .wj-nodelist .wj-node.wj-state-collapsed:before,\n.custom-tree.wj-treeview .wj-nodelist .wj-node.wj-state-collapsing:before {\n  -webkit-transform: rotate(-180deg);\n      -ms-transform: rotate(-180deg);\n          transform: rotate(-180deg);\n  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlci90cmFuZy1jaHUvQzpcXHhhbXBwXFxodGRvY3NcXHRoYW1fbXlfdmllbi9zcmNcXGFwcFxcdXNlclxcdHJhbmctY2h1XFx0cmFuZy1jaHUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUFhO0VBQ2IsYUFBWTtFQUVaLDhFQUE2RTtFQUM3RSxjQUFhO0VBQ2IsdUJBQXNCO0VBQ3RCLGdCQUFlO0VBQ2YsZUFBYyxFQUFHOztBQUNqQjtFQUVFLDhFQUE2RTtFQUU3RSxtQkFBa0IsRUFBRzs7QUFDdkI7RUFDRSxnQkFBZSxFQUFHOztBQUNsQjtFQUNFLGlCQUFnQixFQUFHOztBQUV6QjtFQUNFOzs7SUFHRSxvQkFBbUIsRUFBRyxFQUFBOztBQUUxQjtFQUNFO0lBQ0UsY0FBYSxFQUFHLEVBQUE7O0FBSXRCLHdCQUF3Qjs7QUFDeEI7RUFHSSxhQUFXO0VBQ1gsWUFBVztFQUNYLHNCQUFxQjtFQUNyQixvQkFBbUI7RUFDbkIsZ0JBQWUsRUFDbEI7O0FBRUQsd0JBQXdCOztBQUN4QjtFQUNJLGVBQWU7RUFDZixrQkFBaUI7RUFDakIsZUFBYztFQUNkLHVDQUFzQztFQUN0QyxpQkFBZ0IsRUFDbkI7O0FBRUQsOEJBQThCOztBQUM5QjtFQUNJLGdCQUFlLEVBQ2xCOztBQUVELDBFQUEwRTs7QUFDMUU7O0VBRUksZ0JBQWU7RUFDZiw2Q0FBNEMsRUFDL0M7O0FBRUQsNkRBQTZEOztBQUM3RDs7RUFFSSxnQkFBZTtFQUNmLDZDQUE0QyxFQUMvQzs7QUFFRCx5QkFBeUI7O0FBQ3pCO0VBQ0ksaUJBQWdCO0VBQ2hCLG9DQUFtQztFQUNuQyxTQUFRO0VBQ1IsYUFBWTtFQUNaLFlBQVc7RUFDWCxrREFBMkMsRUFDOUM7O0FBRUQsMEJBQTBCOztBQUMxQjs7RUFFSSxtQ0FBMEI7TUFBMUIsK0JBQTBCO1VBQTFCLDJCQUEwQjtFQUMxQixrREFBMkMsRUFDOUMiLCJmaWxlIjoic3JjL2FwcC91c2VyL3RyYW5nLWNodS90cmFuZy1jaHUuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc2lkZWJhci1maXhlZCB7XHJcbiAgICBoZWlnaHQ6IDEwMHZoO1xyXG4gICAgd2lkdGg6IDI3MHB4O1xyXG4gICAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDJweCA1cHggMCByZ2JhKDAsIDAsIDAsIDAuMTYpLCAwIDJweCAxMHB4IDAgcmdiYSgwLCAwLCAwLCAwLjEyKTtcclxuICAgIGJveC1zaGFkb3c6IDAgMnB4IDVweCAwIHJnYmEoMCwgMCwgMCwgMC4xNiksIDAgMnB4IDEwcHggMCByZ2JhKDAsIDAsIDAsIDAuMTIpO1xyXG4gICAgei1pbmRleDogMTA1MDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XHJcbiAgICBwYWRkaW5nOiAxLjVyZW07XHJcbiAgICBwYWRkaW5nLXRvcDogMDsgfVxyXG4gICAgLnNpZGViYXItZml4ZWQgLmxpc3QtZ3JvdXAgLmFjdGl2ZSB7XHJcbiAgICAgIC13ZWJraXQtYm94LXNoYWRvdzogMCAycHggNXB4IDAgcmdiYSgwLCAwLCAwLCAwLjE2KSwgMCAycHggMTBweCAwIHJnYmEoMCwgMCwgMCwgMC4xMik7XHJcbiAgICAgIGJveC1zaGFkb3c6IDAgMnB4IDVweCAwIHJnYmEoMCwgMCwgMCwgMC4xNiksIDAgMnB4IDEwcHggMCByZ2JhKDAsIDAsIDAsIDAuMTIpO1xyXG4gICAgICAtd2Via2l0LWJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgICAgYm9yZGVyLXJhZGl1czogNXB4OyB9XHJcbiAgICAuc2lkZWJhci1maXhlZCAubG9nby13cmFwcGVyIHtcclxuICAgICAgcGFkZGluZzogMi41cmVtOyB9XHJcbiAgICAgIC5zaWRlYmFyLWZpeGVkIC5sb2dvLXdyYXBwZXIgaW1nIHtcclxuICAgICAgICBtYXgtaGVpZ2h0OiA1MHB4OyB9XHJcbiAgXHJcbiAgQG1lZGlhIChtaW4td2lkdGg6IDEyMDBweCkge1xyXG4gICAgLm5hdmJhcixcclxuICAgIC5wYWdlLWZvb3RlcixcclxuICAgIG1haW4ge1xyXG4gICAgICBwYWRkaW5nLWxlZnQ6IDI3MHB4OyB9IH1cclxuICBcclxuICBAbWVkaWEgKG1heC13aWR0aDogMTE5OS45OHB4KSB7XHJcbiAgICAuc2lkZWJhci1maXhlZCB7XHJcbiAgICAgIGRpc3BsYXk6IG5vbmU7IH0gfVxyXG4gIFxyXG5cclxuIFxyXG4vKiBjdXN0b20gdHJlZSBzdHlsZXMgKi9cclxuLmN1c3RvbS1jYXJkICB7XHJcbiAgICAvLyBjb2xvcjogIzgwMDQ0ZDtcclxuICAgIC8vIG1hcmdpbi10b3A6IDUycHg7XHJcbiAgICB3aWR0aDozMDBweDtcclxuICAgIGZsb2F0OiBsZWZ0O1xyXG4gICAgcGFkZGluZy1ib3R0b206IDUwMHB4O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAzNTJweDtcclxuICAgIHBvc2l0aW9uOiBmaXhlZDtcclxufVxyXG5cclxuLyogY3VzdG9tIHRyZWUgc3R5bGVzICovXHJcbi5jdXN0b20tdHJlZS53ai10cmVldmlldyAge1xyXG4gICAgY29sb3I6ICM1YzZiYzAgO1xyXG4gICAgcGFkZGluZy10b3A6IDM1cHg7IFxyXG4gICAgZm9udC1zaXplOiA3NSU7XHJcbiAgICBmb250LWZhbWlseTogXCJIZWx2ZXRpY2FcIiwgVGltZXMsIHNlcmlmO1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxufVxyXG5cclxuLyogbGV2ZWwgMCBhbmQgZGVlcGVyIG5vZGVzICovXHJcbi5jdXN0b20tdHJlZS53ai10cmVldmlldyAud2otbm9kZWxpc3QgPiAud2otbm9kZSAge1xyXG4gICAgZm9udC1zaXplOiAxMDAlO1xyXG59XHJcblxyXG4vKiBsZXZlbCAxIGFuZCBkZWVwZXIgbm9kZXMgKGxhcmdlciBmb250LCB2ZXJ0aWNhbCBsaW5lIGFsb25nIHRoZSBsZWZ0KSAqL1xyXG4uY3VzdG9tLXRyZWUud2otdHJlZXZpZXcgLndqLW5vZGVsaXN0ID4gLndqLW5vZGVsaXN0ID4gLndqLW5vZGUsXHJcbi5jdXN0b20tdHJlZS53ai10cmVldmlldyAud2otbm9kZWxpc3QgPiAud2otbm9kZWxpc3QgPiAud2otbm9kZWxpc3QgIHtcclxuICAgIGZvbnQtc2l6ZTogMTAwJTtcclxuICAgIGJvcmRlci1sZWZ0OiA0cHggc29saWQgcmdiYSgxMjgsIDQsIDc3LCAwLjMpO1xyXG59XHJcblxyXG4vKiBsZXZlbCAyIGFuZCBkZWVwZXIgbm9kZXMgKHNtYWxsZXIgZm9udCwgdGhpbm5lciBib3JkZXIpICovXHJcbi5jdXN0b20tdHJlZS53ai10cmVldmlldyAud2otbm9kZWxpc3QgPiAud2otbm9kZWxpc3QgID4gLndqLW5vZGVsaXN0ID4gLndqLW5vZGUsXHJcbi5jdXN0b20tdHJlZS53ai10cmVldmlldyAud2otbm9kZWxpc3QgPiAud2otbm9kZWxpc3QgID4gLndqLW5vZGVsaXN0ID4gLndqLW5vZGVsaXN0ICB7XHJcbiAgICBmb250LXNpemU6IDEwMCU7XHJcbiAgICBib3JkZXItbGVmdDogMnB4IHNvbGlkIHJnYmEoMTI4LCA0LCA3NywgMC4zKTtcclxufVxyXG5cclxuLyogZXhwYW5kZWQgbm9kZSBnbHlwaCAqL1xyXG4uY3VzdG9tLXRyZWUud2otdHJlZXZpZXcgLndqLW5vZGVsaXN0IC53ai1ub2RlOmJlZm9yZSAgeyBcclxuICAgIGNvbnRlbnQ6IFwiXFxlMTE0XCI7XHJcbiAgICBmb250LWZhbWlseTogJ0dseXBoaWNvbnMgSGFsZmxpbmdzJztcclxuICAgIHRvcDogNHB4O1xyXG4gICAgYm9yZGVyOiBub25lO1xyXG4gICAgb3BhY2l0eTogLjM7XHJcbiAgICB0cmFuc2l0aW9uOiBhbGwgLjNzIGN1YmljLWJlemllciguNCwwLC4yLDEpO1xyXG59XHJcblxyXG4vKiBjb2xsYXBzZWQgbm9kZSBnbHlwaCAqL1xyXG4uY3VzdG9tLXRyZWUud2otdHJlZXZpZXcgLndqLW5vZGVsaXN0IC53ai1ub2RlLndqLXN0YXRlLWNvbGxhcHNlZDpiZWZvcmUsXHJcbi5jdXN0b20tdHJlZS53ai10cmVldmlldyAud2otbm9kZWxpc3QgLndqLW5vZGUud2otc3RhdGUtY29sbGFwc2luZzpiZWZvcmUgIHtcclxuICAgIHRyYW5zZm9ybTogcm90YXRlKC0xODBkZWcpO1xyXG4gICAgdHJhbnNpdGlvbjogYWxsIC4zcyBjdWJpYy1iZXppZXIoLjQsMCwuMiwxKTtcclxufVxyXG4gICAgIl19 */"

/***/ }),

/***/ "./src/app/user/trang-chu/trang-chu.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/user/trang-chu/trang-chu.component.ts ***!
  \*******************************************************/
/*! exports provided: TrangChuComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TrangChuComponent", function() { return TrangChuComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var src_app_admin_extral_admin_common_login_cookie__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/admin/extral-admin/common/login-cookie */ "./src/app/admin/extral-admin/common/login-cookie.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



// import { Router } from '@angular/router';
var TrangChuComponent = /** @class */ (function () {
    function TrangChuComponent(router, loginCookie) {
        this.router = router;
        this.loginCookie = loginCookie;
    }
    TrangChuComponent.prototype.ngOnInit = function () {
    };
    TrangChuComponent.prototype.ngAfterViewInit = function () {
    };
    TrangChuComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-trang-chu',
            template: __webpack_require__(/*! ./trang-chu.component.html */ "./src/app/user/trang-chu/trang-chu.component.html"),
            styles: [__webpack_require__(/*! ./trang-chu.component.scss */ "./src/app/user/trang-chu/trang-chu.component.scss")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            src_app_admin_extral_admin_common_login_cookie__WEBPACK_IMPORTED_MODULE_2__["LoginCookie"]])
    ], TrangChuComponent);
    return TrangChuComponent;
}());



/***/ }),

/***/ "./src/app/user/trang-chu/trang-chu.module.ts":
/*!****************************************************!*\
  !*** ./src/app/user/trang-chu/trang-chu.module.ts ***!
  \****************************************************/
/*! exports provided: TrangChuModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TrangChuModule", function() { return TrangChuModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _trang_chu_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./trang-chu.component */ "./src/app/user/trang-chu/trang-chu.component.ts");
/* harmony import */ var angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! angular-bootstrap-md */ "./node_modules/angular-bootstrap-md/esm5/angular-bootstrap-md.es5.js");
/* harmony import */ var _image_image_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./image/image.component */ "./src/app/user/trang-chu/image/image.component.ts");
/* harmony import */ var _intro_intro_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./intro/intro.component */ "./src/app/user/trang-chu/intro/intro.component.ts");
/* harmony import */ var _dich_vu_dich_vu_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./dich-vu/dich-vu.component */ "./src/app/user/trang-chu/dich-vu/dich-vu.component.ts");
/* harmony import */ var _slide_slide_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./slide/slide.component */ "./src/app/user/trang-chu/slide/slide.component.ts");
/* harmony import */ var _event_event_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./event/event.component */ "./src/app/user/trang-chu/event/event.component.ts");
/* harmony import */ var _danh_gia_khach_danh_gia_khach_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./danh-gia-khach/danh-gia-khach.component */ "./src/app/user/trang-chu/danh-gia-khach/danh-gia-khach.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};












var routing = [{
        path: '', component: _trang_chu_component__WEBPACK_IMPORTED_MODULE_4__["TrangChuComponent"],
        children: [
        // {
        //   path: 'quan-ly-nhap-diem/:khoi', component: QuanLyNhapDiemComponent
        // },
        // { path: 'cai-dat-cot-diem/:khoi', component: CaiDatCotDiemComponent },
        // { path: 'quan-ly-ngay-nghi/:khoi', component: QuanLyNgayNghiComponent },
        // { path: 'quan-ly-hoc-sinh/quan-ly-chuyen-lop', component: QuanLyHocSinhComponent },
        // {
        //   path: 'login', component: LoginComponent,
        //   children: [
        //     { path: 'login', component: LogInComponent },
        //     { path: 'forget-password', component: ForgetPasswordComponent },
        //   ]
        // },
        ]
    }];
var TrangChuModule = /** @class */ (function () {
    function TrangChuModule() {
    }
    TrangChuModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            declarations: [
                _trang_chu_component__WEBPACK_IMPORTED_MODULE_4__["TrangChuComponent"],
                _image_image_component__WEBPACK_IMPORTED_MODULE_6__["ImageComponent"],
                _intro_intro_component__WEBPACK_IMPORTED_MODULE_7__["IntroComponent"],
                _dich_vu_dich_vu_component__WEBPACK_IMPORTED_MODULE_8__["DichVuComponent"],
                _slide_slide_component__WEBPACK_IMPORTED_MODULE_9__["SlideComponent"],
                _event_event_component__WEBPACK_IMPORTED_MODULE_10__["EventComponent"],
                _danh_gia_khach_danh_gia_khach_component__WEBPACK_IMPORTED_MODULE_11__["DanhGiaKhachComponent"],
            ],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routing),
                angular_bootstrap_md__WEBPACK_IMPORTED_MODULE_5__["MDBBootstrapModule"].forRoot(),
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
            ],
            entryComponents: [
                _trang_chu_component__WEBPACK_IMPORTED_MODULE_4__["TrangChuComponent"]
            ],
            exports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"]]
        })
    ], TrangChuModule);
    return TrangChuModule;
}());



/***/ })

}]);
//# sourceMappingURL=trang-chu-trang-chu-module.js.map